import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Program3 {

	public static void main(String[] args) {
		List<Fruits> fruits = new ArrayList<>();
		Fruits fruit1 = new Fruits("Apple",1000,"Kashmir");
		Fruits fruit2 = new Fruits("Orange",2000,"Himachal");
		Fruits fruit3 = new Fruits("Apple",1000,"Kerala");
		Fruits fruit4 = new Fruits("Orange",2000,"Tamilnadu");
		Fruits fruit5 = new Fruits("Apple",1000,"Karnataka");
		
		fruits.add(fruit1);
		fruits.add(fruit2);
		fruits.add(fruit3);
		fruits.add(fruit4);
		fruits.add(fruit5);
		
		//System.out.println(fruits);
		Map<String, List<Fruits>> values = fruits.stream().collect(Collectors.groupingBy(fruit ->fruit.getName()));
		//int summingPrice = fruits.stream().collect(Collectors.summingInt(Fruits::getPrice));
		Map<String, Integer > values2 = fruits.stream().collect(Collectors.groupingBy(fruit ->fruit.getName(),Collectors.summingInt(Fruits::getPrice)));
		//System.out.println(values2);
		//System.out.println(summingPrice);
System.out.println(values);


	}

}
