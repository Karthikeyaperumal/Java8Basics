import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Program5 {

	public static void main(String[] args) {

		List<Integer> values = new ArrayList<>();
		values.add(3);
		values.add(8);
		values.add(9);
		values.add(6);
		values.add(2);
		
		System.out.println(values);
		
		//ascending
		List<Integer> ascending = values.stream().sorted().collect(Collectors.toList());
		System.out.println(ascending);
		//System.out.println(ascending.stream().skip(1).limit(2).collect(Collectors.toList()));

		//descending
		List<Integer> descending = values.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		System.out.println(descending);
	}

}
