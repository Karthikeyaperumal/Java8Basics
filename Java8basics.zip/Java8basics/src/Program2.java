import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Program2 {

	public static void main(String[] args) {

		List<Employee> employee = new ArrayList<>();
		Employee employee1 = new Employee("Karthik","Tuticorin",24);
		Employee employee2 = new Employee("Vijay","Tuticorin",21);
		Employee employee3 = new Employee("Surya","Madurai",24);
		Employee employee4 = new Employee("Ajith","Tirchy",22);
		Employee employee5 = new Employee("Shiva","Tuticorin",22);

		employee.add(employee1);
		employee.add(employee2);
		employee.add(employee3);
		employee.add(employee4);
		employee.add(employee5);

		System.out.println(employee);
		Map<String, List<Employee>> values = employee.stream().collect(Collectors.groupingBy(emp -> emp.getCity()));
		System.out.println(values);
	}

}
