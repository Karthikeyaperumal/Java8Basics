import java.util.ArrayList;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.stream.Collectors;

public class Program4 {

	public static void main(String[] args) {

		List<Employee4> employ = new ArrayList<>();
		Employee4 employ1 = new Employee4("Karthik", 1, 10000);
		Employee4 employ2 = new Employee4("Vijay", 2, 20000);
		Employee4 employ3 = new Employee4("Ajith", 3, 30000);
		Employee4 employ4 = new Employee4("Surya",4, 40000);
		Employee4 employ5 = new Employee4("Surya", 5, 50000);
		
		employ.add(employ1);
		employ.add(employ2);
		employ.add(employ3);
		employ.add(employ4);
		employ.add(employ5);
		
		System.out.println(employ);
		List<Integer> salary = employ.stream().map(emp->emp.getSalary()).collect(Collectors.toList());
		System.out.println(salary);
		System.out.println("Max :"+ salary.stream().mapToInt(x->x).summaryStatistics().getMax());
		System.out.println("Min :"+salary.stream().mapToInt(x->x).summaryStatistics().getMin());
		System.out.println("Sum :"+salary.stream().mapToInt(x->x).summaryStatistics().getSum());
		
		List<String> distinct = employ.stream().map(emp -> emp.getName()).distinct().collect(Collectors.toList());
		System.out.println(distinct);

				//int summaryy = employ.stream().collect(Collectors.summarizingInt(employ::get));
		//IntSummaryStatistics summary = employ.stream().collect(Collectors.summarizingInt());

	}

	
	
	}

	


